package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private Button mBtnTextview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBtnTextview = findViewById(R.id.btn);
        mBtnTextview.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(MainActivity.this,TextviewActivity.class);
////                startActivity(intent);
                String ans;
                EditText et = findViewById(R.id.et_1);
                String word = et.getText().toString();
                try {

                    InputStreamReader inputReader = new InputStreamReader( getResources().getAssets().open("3391.txt") );
                    BufferedReader bufReader = new BufferedReader(inputReader);
                    String line="";
                    String Result="";
                    String temp = "";
                    int num = 0;
                    TextView tv = findViewById(R.id.tv_1);
                    while ((line = bufReader.readLine()) != null) {
                        if(line.length() > 3)
                            if(line.charAt(0) == '0' || line.charAt(0) == '1' || line.charAt(0) == '2' || line.charAt(0) == '3'){
                                temp = " (" + line + ")";
                                continue;
                            }
                        if (line.contains(word)) {
                            num++;
                            Result += " " + num + "." + line + temp + "\n";
                        }
                    }
                    Result = "共搜索到" + num +"条结果.\n" + Result;
                    SpannableStringBuilder newResult = new SpannableStringBuilder(Result);
                    int k = 0;
                    while( k >= 0)
                    {
                        int l=Result.indexOf(word, k);
                        int r = l + word.length();
                        if (l == -1)
                            break;
                        k = l + 1;
                        newResult.setSpan(new ForegroundColorSpan(Color.RED),l,r,Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                    }
                    tv.setText(newResult);
                    tv.setMovementMethod(ScrollingMovementMethod.getInstance());
                }
                catch (Exception e)
                {
                    TextView tv = findViewById(R.id.tv_1);
                    ans = "抱歉，程序已崩溃，请联系程序开发者!";
                    tv.setText(ans);
                }
            }
        });
    }
}
