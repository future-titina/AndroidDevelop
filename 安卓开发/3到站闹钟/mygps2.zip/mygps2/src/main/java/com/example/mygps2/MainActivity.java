package com.example.mygps2;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Context mContext;
    private WebView webView;
    private TextView textView,textView2;
    private LocationManager mLocationManager;
    private String locationProvider;
    private double x,y,juli=500,jingdu,weidu;
    private  EditText et1,et2;
    private MediaPlayer m;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        initLocationManger(mContext);
    }

    private void init() {
        mContext = this;

        textView = findViewById(R.id.tv);
        webView = findViewById(R.id.wv);

        et1 = findViewById(R.id.et_1);
        et2 = findViewById(R.id.et_2);
        textView2 = findViewById(R.id.tv_2);

        m = MediaPlayer.create(this, R.raw.a);
        WebSettings iset = webView.getSettings();
        webView.setWebViewClient(new MyWebViewClient());
        webView.setWebChromeClient(new MyWebChromeClient());
        webView.getSettings().setCacheMode( WebSettings.LOAD_CACHE_ELSE_NETWORK);
        iset.setJavaScriptEnabled(true);
        iset.setUseWideViewPort(true);
        iset.setLoadWithOverviewMode(true);
        webView.loadUrl("https://www.earthol.com/");
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    private void initLocationManger(Context context) {

        mLocationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        locationProvider = LocationManager.GPS_PROVIDER;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Location location = mLocationManager.getLastKnownLocation(locationProvider);
        if (location!=null) {
            x = location.getLongitude();
            y = location.getLatitude();
            textView.setText("当前经度：" + location.getLongitude() + "\n当前纬度：" +location.getLatitude());
        } else {
            Toast.makeText(getApplicationContext(),"Location == NULL", Toast.LENGTH_SHORT).show();
        }
        mLocationManager.requestLocationUpdates(locationProvider, 0, 0, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if(location != null){
                    textView.setText("当前经度：" + location.getLongitude() + "\n当前纬度：" +location.getLatitude());
                    juli = algorithm(x, y, jingdu,weidu);
                    textView2.setText("当前与目的地直线距离:" + juli + "米");
                }

                if(juli < 500){
                   m.start();
                }


            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        });
    }

    public void btn_onClick(View view) {

        jingdu =  Double.parseDouble(et1.getText().toString());
        weidu =  Double.parseDouble(et2.getText().toString());
        juli = algorithm(x, y, jingdu,weidu);

        textView2.setText("当前与目的地直线距离:" + juli + "米");
    }

    public static double algorithm(double longitude1, double latitude1, double longitude2, double latitude2) {
        double Lat1 = rad(latitude1); // 纬度
        double Lat2 = rad(latitude2);
        double a = Lat1 - Lat2;//两点纬度之差
        double b = rad(longitude1) - rad(longitude2); //经度之差
        double s = 2 * Math.asin(Math
                .sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(Lat1) * Math.cos(Lat2) * Math.pow(Math.sin(b / 2), 2)));//计算两点距离的公式
        s = s * 6378137.0;//弧长乘地球半径（半径为米）
        s = Math.round(s * 10000d) / 10000d;//精确距离的数值
        return s;
    }
    private static double rad(double d) {
        return d * Math.PI / 180.00; //角度转换成弧度
    }

    class MyWebViewClient extends WebViewClient{
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            view.loadUrl(request.getUrl().toString());
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            Log.d("WebView","onPageStarted");
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            Log.d("WebView","onPageFinished");
        }
    }

    class MyWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);

            Log.d("SEARCH_TAG", "on page progress changed and progress is " + newProgress);
            // 进度是100就代表dom树加载完成了
            if (newProgress == 100) {
                //内嵌js脚本
                webView.loadUrl("javascript:document.xyform.x.value="+x+";document.xyform.y.value="+y+";gotoxy();");
            }
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            setTitle(title);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()){
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
