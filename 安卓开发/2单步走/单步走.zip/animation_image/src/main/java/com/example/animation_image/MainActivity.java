package com.example.animation_image;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imv1 = (ImageView)findViewById(R.id.id_imv);
        imv1.setBackgroundResource(R.drawable.an1);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void onClick_go(View view)
    {
        TextView textview = (TextView)findViewById(R.id.tv_hw);
        textview.setText("going");

        ImageView imv1 = (ImageView)findViewById(R.id.id_imv);
        AnimationDrawable ad1 = new AnimationDrawable(); //(AnimationDrawable)imv1.getBackground();
        Bitmap[] bitmaps = new Bitmap[32];
        Bitmap  big = BitmapFactory.decodeResource(getResources(), R.drawable.an1);

        DisplayMetrics dmt = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dmt);
        float den=dmt.density;

        for (int frame = 0; frame < bitmaps.length; frame++) {
            Bitmap b1 = Bitmap.createBitmap(big,(int)((frame%8)*120*den), (int)((frame/8)*150*den),
                    (int)(120*den), (int)(150*den));
            ad1.addFrame(new BitmapDrawable (getResources(),b1),100);
        }
        imv1.setBackground(ad1);
        ad1.start();
    }
}
